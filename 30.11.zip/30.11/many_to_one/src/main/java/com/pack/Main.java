package com.pack;

import java.util.Iterator;
import java.util.List;

import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.query.Query;

 public class Main {

	public static void main(String[] args) {
 
		  Session session=null;
		  Transaction transaction = null;
			 
	try {
		  SessionFactory factory=HibernateUtil.getSessionFactory();
		    session=factory.openSession(); 
		  
		 
	      
			transaction = session.beginTransaction();
			Address address1 = new Address("OMR Road", "Chennai", "TN", "60097");
			Address address2 = new Address("Ring Road", "Hyderabad", "Andhra Pradhesh", "56000");
			
			Student student1 = new Student("Priya",address1);
			Student student2 = new Student("Joe", address1);
			 
			
			session.save(student1);
			session.save(student2);
		   
			student1.getStudentAddress().getCity();
		  
		 
		   
			System.out.println(student1.getStudentAddress().getCity());
		   
			String sql_query="select a.studentName,b.city from Student a,Address b where  a.studentAddress=b.addressId  and a.studentAddress=29";
		   		 
		    Query<?> q=session.createQuery(sql_query);
		   
		    List<?> list=q.getResultList();
		  
		    Iterator<?> itr=list.iterator();
		    	
		    	 while (itr.hasNext())
		    	 {
			       Object[] row = (Object[]) itr.next();
			       System.out.println("Name: " + row[0]);
			       System.out.println("City: " + row[1]);
			     
			     }
		    transaction.commit();
  
		} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}

	}

}
