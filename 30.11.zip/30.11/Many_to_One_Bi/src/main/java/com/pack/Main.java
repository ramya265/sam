package com.pack;

import org.hibernate.HibernateException;
 
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.boot.MetadataSources;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import org.hibernate.query.Query;

import java.util.*;


public class Main {

	public static void main(String[] args) {

		   
			
			 
		 
			 

}
			 
			
			
			
			
			
			
			
		
			
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
		 	/* address1=(Address)session.get(Address.class,167L);	 
			 
			System.out.println("Students who belong to address1 object");
			
			Set<Student> s1=address1.getPeople();
			
				for (Iterator itr=s1.iterator();itr.hasNext();)
				{
	 		         Student S=(Student)itr.next();
			         System.out.println(S.getStudentName());
				}
		
				
				
				String sql_query="select a.studentName,b.city from Student a," +
						"Address b where  a.studentAddress=b.addressId  and" +
						" a.studentAddress=167";
		   		 
			    Query q=session.createQuery(sql_query);
			   
			    for(Iterator it=q.iterate();it.hasNext();){
			    	
			    	 
				       Object[] row = (Object[]) it.next();
				       System.out.println("Name: " + row[0]);
				       System.out.println("City: " + row[1]);
				     
				     }*/
				  	 
			    
		/*} catch (HibernateException e) {
			transaction.rollback();
			e.printStackTrace();
		} finally {
			session.close();
		}*/

	}

}
